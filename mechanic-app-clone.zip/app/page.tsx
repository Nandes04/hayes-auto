"use client"

import { AuthProvider, useAuth } from "@/lib/auth-context"
import { LoginPage } from "@/components/login-page"
import { Navbar, type Page as NavPage } from "@/components/navbar"
import { HomePage } from "@/components/home-page"
import { ServicePage } from "@/components/service-page"
import { LogisticsPage } from "@/components/logistics-page"
import { StockPage } from "@/components/stock-page"
import { useState } from "react"

function AppContent() {
  const { user } = useAuth()
  const [activePage, setActivePage] = useState<NavPage>("home")

  if (!user) {
    return <LoginPage />
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Navbar activePage={activePage} onNavigate={setActivePage} />
      {activePage === "home" && <HomePage onNavigate={setActivePage} />}
      {activePage === "servico" && <ServicePage />}
      {activePage === "logistica" && <LogisticsPage />}
      {activePage === "stock" && <StockPage />}
    </div>
  )
}

export default function Page() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  )
}
