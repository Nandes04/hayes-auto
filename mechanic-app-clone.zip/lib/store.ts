// Materials / Stock data
export const MATERIALS = [
  { name: "Barra Cobre", stock: 843 },
  { name: "Barra Ferro", stock: 670 },
  { name: "Borracha", stock: 592 },
  { name: "Aco", stock: 169 },
  { name: "Plastico", stock: 170 },
  { name: "Eletronicos", stock: 25 },
  { name: "Prata", stock: 206 },
  { name: "Aluminio", stock: 1048 },
  { name: "Carvao", stock: 849 },
  { name: "Zinco", stock: 60 },
  { name: "Nitro Vazia", stock: 0 },
  { name: "Bauxite", stock: 689 },
  { name: "Combustivel", stock: 892 },
  { name: "Sucata", stock: 81 },
  { name: "Fio de Cobre", stock: 75 },
] as const

// Parts / Pecas data
export interface Part {
  name: string
  price: number
}

export const PARTS: Part[] = [
  { name: "Bateria EV", price: 1700 },
  { name: "Combustivel", price: 0 },
  { name: "Conjunto de Rodas", price: 2500 },
  { name: "Controlador Iluminacao", price: 1800 },
  { name: "Embraiagem", price: 500 },
  { name: "Filtro de Ar", price: 300 },
  { name: "Fita Adesiva", price: 3500 },
  { name: "Garrafa de Nitro", price: 10000 },
  { name: "Kit de Extras", price: 3900 },
  { name: "Kit Fumo Pneus", price: 4400 },
  { name: "Kit Nitro", price: 10000 },
  { name: "Kit Limpeza", price: 4500 },
  { name: "Kit de Reparacao", price: 2500 },
  { name: "Kit de Pintura", price: 2500 },
  { name: "Oleo do Motor", price: 800 },
  { name: "Pastilhas de Travao", price: 600 },
  { name: "Pecas Cosmeticas", price: 1200 },
  { name: "Pecas de Suspensao", price: 900 },
  { name: "Pneus de Substituicao", price: 700 },
  { name: "Vela de Ignicao", price: 400 },
]

// Menu (complete service packages)
export interface Menu {
  name: string
  parts: { name: string; qty: number }[]
  price: number
}

export const MENUS: Menu[] = [
  {
    name: "Full Tune",
    parts: [
      { name: "Filtro de Ar", qty: 1 },
      { name: "Oleo do Motor", qty: 1 },
      { name: "Vela de Ignicao", qty: 4 },
      { name: "Pastilhas de Travao", qty: 4 },
    ],
    price: 3500,
  },
  {
    name: "Cosmetic Pack",
    parts: [
      { name: "Kit de Pintura", qty: 1 },
      { name: "Pecas Cosmeticas", qty: 6 },
    ],
    price: 9700,
  },
  {
    name: "Performance Pack",
    parts: [
      { name: "Kit Nitro", qty: 1 },
      { name: "Kit Fumo Pneus", qty: 1 },
      { name: "Conjunto de Rodas", qty: 1 },
    ],
    price: 16900,
  },
]

// Activity log entries
export interface ActivityEntry {
  mechanic: string
  content: string
  date: string
  billed: number
}

export const RECENT_ACTIVITY: ActivityEntry[] = [
  { mechanic: "RMONTEIRO", content: "12x Pecas Cosmeticas, 1x Kit de Pintura, 1x Conjunto de Rodas", date: "13/02/2026", billed: 26560 },
  { mechanic: "MCASTILLO", content: "2x Controlador Iluminacao", date: "13/02/2026", billed: 3600 },
  { mechanic: "MCASTILLO", content: "18x Pecas Cosmeticas, 6x Kit de Pintura, 1x Kit Fumo Pneus, 1x Conjunto de Rodas", date: "13/02/2026", billed: 21900 },
  { mechanic: "RMONTEIRO", content: "1x Kit de Reparacao", date: "13/02/2026", billed: 2500 },
  { mechanic: "RMONTEIRO", content: "4x Kit de Reparacao", date: "13/02/2026", billed: 10000 },
  { mechanic: "RMONTEIRO", content: "2x Combustivel, 1x Embraiagem, 1x Filtro de Ar, 1x Oleo do Motor, 4x Pastilhas de Travao, 1x Pecas de Suspensao, 4x Pneus de Substituicao, 4x Vela de Ignicao", date: "13/02/2026", billed: 10000 },
  { mechanic: "RMONTEIRO", content: "1x Oleo do Motor, 1x Filtro de Ar, 4x Vela de Ignicao, 4x Pneus de Substituicao", date: "13/02/2026", billed: 7000 },
  { mechanic: "SAMANTA", content: "1x Kit de Pintura", date: "13/02/2026", billed: 2500 },
  { mechanic: "SAMANTA", content: "1x Kit de Reparacao", date: "13/02/2026", billed: 2500 },
]

// Notices
export interface Notice {
  text: string
  author: string
  date: string
}

export const NOTICES: Notice[] = [
  { text: "Discord da oficina - https://discord.gg/d2PBRvUucH", author: "JBLACK", date: "29/01/2026" },
  { text: "Radio da Oficina: 529", author: "ADMIN", date: "27/01/2026" },
  { text: "Se por exemplo fizerem um full tune, o valor da pecas de performance sao cobrados em jogo, coloquem o valor ja cobrado in-game no Campo acima do Total!", author: "ADMIN", date: "26/01/2026" },
  { text: "Se fizerem servicos para voces mesmo, seja kits ou outra coisa qualquer quando selecionam a peca aparece um Saco de Dinheiro ao lado do remover, cliquem nesse Saco", author: "ADMIN", date: "26/01/2026" },
]

// Reimbursements
export interface Reimbursement {
  material: string
  qty: number
  cost: number
  status: "PAGO" | "PENDENTE"
}

export const REIMBURSEMENTS: Reimbursement[] = [
  { material: "Plastico", qty: 6, cost: 0, status: "PAGO" },
  { material: "Sucata", qty: 7, cost: 0, status: "PAGO" },
  { material: "Barra Ferro", qty: 145, cost: 0, status: "PAGO" },
  { material: "Bauxite", qty: 133, cost: 0, status: "PAGO" },
  { material: "Aluminio", qty: 8, cost: 0, status: "PAGO" },
  { material: "Aco", qty: 7, cost: 0, status: "PAGO" },
  { material: "Borracha", qty: 3, cost: 0, status: "PAGO" },
  { material: "Eletronicos", qty: 11, cost: 0, status: "PAGO" },
  { material: "Plastico", qty: 6, cost: 0, status: "PAGO" },
  { material: "Sucata", qty: 15, cost: 0, status: "PAGO" },
  { material: "Aco", qty: 2, cost: 0, status: "PAGO" },
  { material: "Sucata", qty: 4, cost: 0, status: "PAGO" },
  { material: "Eletronicos", qty: 2, cost: 0, status: "PAGO" },
  { material: "Aluminio", qty: 1, cost: 0, status: "PAGO" },
]

// Demo users
export const USERS = [
  { username: "galinha", password: "1234", role: "mechanic" as const },
  { username: "admin", password: "admin", role: "admin" as const },
  { username: "rmonteiro", password: "1234", role: "mechanic" as const },
]
