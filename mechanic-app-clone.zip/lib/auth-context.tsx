"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"
import { USERS } from "./store"

interface User {
  username: string
  role: "mechanic" | "admin"
}

interface AuthContextType {
  user: User | null
  login: (username: string, password: string) => boolean
  logout: () => void
}

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  const login = useCallback((username: string, password: string): boolean => {
    const found = USERS.find(
      (u) => u.username.toLowerCase() === username.toLowerCase() && u.password === password
    )
    if (found) {
      setUser({ username: found.username, role: found.role })
      return true
    }
    return false
  }, [])

  const logout = useCallback(() => {
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) throw new Error("useAuth must be used within AuthProvider")
  return context
}
