"use client"

import { useAuth } from "@/lib/auth-context"
import { cn } from "@/lib/utils"

const NAV_ITEMS = [
  { key: "home", label: "HOME" },
  { key: "servico", label: "SERVICO" },
  { key: "logistica", label: "LOGISTICA" },
  { key: "stock", label: "STOCK" },
] as const

export type Page = (typeof NAV_ITEMS)[number]["key"]

interface NavbarProps {
  activePage: Page
  onNavigate: (page: Page) => void
}

export function Navbar({ activePage, onNavigate }: NavbarProps) {
  const { logout } = useAuth()

  return (
    <header className="flex items-center justify-between border-b border-border px-6 py-3">
      <div
        className="cursor-pointer rounded border-2 border-primary px-2 py-0.5 font-mono text-sm font-bold italic text-primary"
        onClick={() => onNavigate("home")}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => e.key === "Enter" && onNavigate("home")}
      >
        LSC
      </div>

      <nav className="flex items-center gap-1" role="navigation" aria-label="Main navigation">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.key}
            onClick={() => onNavigate(item.key)}
            className={cn(
              "rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-wider transition-colors",
              activePage === item.key
                ? "border border-primary bg-transparent text-primary"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            {item.label}
          </button>
        ))}
      </nav>

      <button
        onClick={logout}
        className="text-xs font-bold uppercase tracking-wider text-muted-foreground transition-colors hover:text-foreground"
      >
        SAIR
      </button>
    </header>
  )
}
