"use client"

import { MATERIALS } from "@/lib/store"

export function StockPage() {
  return (
    <div className="flex-1 overflow-auto p-6">
      <div className="grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        {MATERIALS.map((material) => (
          <div
            key={material.name}
            className="rounded-lg border border-border bg-card p-5"
          >
            <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              {material.name}
            </p>
            <p
              className={`mt-2 font-mono text-4xl font-bold italic ${
                material.stock === 0
                  ? "text-destructive"
                  : "text-foreground"
              }`}
            >
              {material.stock.toLocaleString("pt-PT")}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
