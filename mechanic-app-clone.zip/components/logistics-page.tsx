"use client"

import { useState } from "react"
import { MATERIALS, REIMBURSEMENTS } from "@/lib/store"

function formatCurrency(value: number): string {
  return (
    value.toLocaleString("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + " \u20AC"
  )
}

export function LogisticsPage() {
  const [material, setMaterial] = useState(MATERIALS[0].name)
  const [quantity, setQuantity] = useState("1")
  const [totalCost, setTotalCost] = useState("0.00")
  const [submitted, setSubmitted] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSubmitted(true)
    setTimeout(() => {
      setSubmitted(false)
      setQuantity("1")
      setTotalCost("0.00")
    }, 2000)
  }

  return (
    <div className="flex flex-1 gap-6 overflow-hidden p-6">
      {/* Left: Reposition Form */}
      <div className="flex-1">
        <div className="rounded-lg border border-border bg-card p-6">
          <h2 className="font-mono text-lg font-bold italic text-foreground">
            REGISTO DE REPOSICAO
          </h2>

          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-5">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Material
                </label>
                <select
                  value={material}
                  onChange={(e) => setMaterial(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border bg-input px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  {MATERIALS.map((m) => (
                    <option key={m.name} value={m.name} className="bg-card text-foreground">
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  Quantidade
                </label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="mt-1 w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {"Custo Total (\u20AC)"}
              </label>
              <input
                type="text"
                value={totalCost}
                onChange={(e) => setTotalCost(e.target.value)}
                className="mt-1 w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>

            <button
              type="submit"
              className="rounded-lg bg-accent py-3 text-sm font-bold uppercase tracking-wider text-accent-foreground transition-opacity hover:opacity-90"
            >
              {submitted ? "Submetido!" : "Submeter e Atualizar Stock"}
            </button>
          </form>
        </div>
      </div>

      {/* Right: Reimbursements */}
      <div className="w-[480px] flex-shrink-0">
        <div className="rounded-lg border border-border bg-card">
          <div className="border-b border-border px-5 py-4">
            <h3 className="font-mono text-sm font-bold uppercase text-foreground">
              Meus Reembolsos
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Material
                  </th>
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Custo
                  </th>
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Estado
                  </th>
                </tr>
              </thead>
              <tbody>
                {REIMBURSEMENTS.map((r, i) => (
                  <tr key={i} className="border-b border-border last:border-0">
                    <td className="px-5 py-3 text-sm text-foreground">
                      {r.material} ({r.qty})
                    </td>
                    <td className="px-5 py-3 font-mono text-sm text-foreground">
                      {formatCurrency(r.cost)}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={
                          r.status === "PAGO"
                            ? "rounded px-2 py-0.5 text-[10px] font-bold text-success"
                            : "rounded px-2 py-0.5 text-[10px] font-bold text-primary"
                        }
                      >
                        {r.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
