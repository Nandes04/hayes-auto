"use client"

import { useState, useMemo } from "react"
import { PARTS, MENUS } from "@/lib/store"
import { Plus, Search, ShoppingCart, Gem, Trash2, Star, Wrench } from "lucide-react"
import { cn } from "@/lib/utils"

interface CartItem {
  name: string
  price: number
  qty: number
}

function formatPrice(value: number): string {
  return (
    value.toLocaleString("pt-PT", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }) + " \u20AC"
  )
}

export function ServicePage() {
  const [tab, setTab] = useState<"parts" | "menus">("parts")
  const [search, setSearch] = useState("")
  const [cart, setCart] = useState<CartItem[]>([])
  const [ingameValue, setIngameValue] = useState("0.00")
  const [resources, setResources] = useState<CartItem[]>([])

  const filteredParts = useMemo(() => {
    const q = search.toLowerCase()
    return PARTS.filter((p) => p.name.toLowerCase().includes(q))
  }, [search])

  function addToCart(name: string, price: number) {
    setCart((prev) => {
      const existing = prev.find((c) => c.name === name)
      if (existing) {
        return prev.map((c) =>
          c.name === name ? { ...c, qty: c.qty + 1 } : c
        )
      }
      return [...prev, { name, price, qty: 1 }]
    })
  }

  function addToResources(name: string, price: number) {
    setResources((prev) => {
      const existing = prev.find((c) => c.name === name)
      if (existing) {
        return prev.map((c) =>
          c.name === name ? { ...c, qty: c.qty + 1 } : c
        )
      }
      return [...prev, { name, price, qty: 1 }]
    })
  }

  function removeFromCart(name: string) {
    setCart((prev) => prev.filter((c) => c.name !== name))
  }

  function removeFromResources(name: string) {
    setResources((prev) => prev.filter((c) => c.name !== name))
  }

  const systemTotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.qty, 0)
  }, [cart])

  const ingameNum = parseFloat(ingameValue.replace(",", ".")) || 0
  const grandTotal = systemTotal + ingameNum

  function handleSubmit() {
    if (cart.length === 0) return
    setCart([])
    setResources([])
    setIngameValue("0.00")
  }

  return (
    <div className="flex flex-1 gap-4 overflow-hidden p-6">
      {/* Left: Parts / Menus catalog */}
      <div className="flex flex-1 flex-col gap-4 overflow-auto">
        {/* Tabs */}
        <div className="flex overflow-hidden rounded-lg border border-border bg-card">
          <button
            onClick={() => setTab("parts")}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 py-3 text-xs font-bold uppercase tracking-wider transition-colors",
              tab === "parts"
                ? "bg-accent text-accent-foreground"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Wrench className="h-4 w-4" />
            Pecas Individuais
          </button>
          <button
            onClick={() => setTab("menus")}
            className={cn(
              "flex flex-1 items-center justify-center gap-2 py-3 text-xs font-bold uppercase tracking-wider transition-colors",
              tab === "menus"
                ? "bg-accent text-accent-foreground"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <Star className="h-4 w-4" />
            Menus Completos
          </button>
        </div>

        {/* Search */}
        <div className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="PROCURAR PECA..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="flex-1 bg-transparent text-sm font-bold uppercase tracking-wider text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
        </div>

        {/* Items grid */}
        {tab === "parts" ? (
          <div className="grid grid-cols-2 gap-3">
            {filteredParts.map((part) => (
              <div
                key={part.name}
                className="flex items-center justify-between rounded-lg border border-border bg-card px-4 py-3"
              >
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-foreground">
                    {part.name}
                  </p>
                  <p className="mt-1 font-mono text-sm font-bold text-success">
                    {formatPrice(part.price)}
                  </p>
                </div>
                <button
                  onClick={() => addToCart(part.name, part.price)}
                  className="flex h-7 w-7 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                  aria-label={`Add ${part.name} to cart`}
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {MENUS.map((menu) => (
              <div
                key={menu.name}
                className="flex flex-col gap-2 rounded-lg border border-border bg-card px-4 py-3"
              >
                <div className="flex items-center justify-between">
                  <p className="text-xs font-bold uppercase tracking-wider text-foreground">
                    {menu.name}
                  </p>
                  <button
                    onClick={() => {
                      menu.parts.forEach((p) => {
                        for (let i = 0; i < p.qty; i++) {
                          const found = PARTS.find(
                            (pp) => pp.name === p.name
                          )
                          if (found) addToCart(found.name, found.price)
                        }
                      })
                    }}
                    className="flex h-7 w-7 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                    aria-label={`Add ${menu.name} to cart`}
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
                <p className="font-mono text-sm font-bold text-success">
                  {formatPrice(menu.price)}
                </p>
                <p className="text-[10px] text-muted-foreground">
                  {menu.parts.map((p) => `${p.qty}x ${p.name}`).join(", ")}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Middle: Cart */}
      <div className="flex w-80 flex-col gap-4">
        <div className="flex flex-1 flex-col rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <h3 className="flex items-center gap-2 font-mono text-sm font-bold text-foreground">
              <ShoppingCart className="h-4 w-4" />
              CARRINHO
            </h3>
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
              {cart.reduce((s, c) => s + c.qty, 0)}
            </span>
          </div>

          <div className="flex-1 overflow-auto p-4">
            {cart.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                <ShoppingCart className="h-8 w-8 opacity-50" />
                <p className="text-xs uppercase tracking-wider">Sem Pecas</p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {cart.map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between rounded border border-border bg-secondary px-3 py-2"
                  >
                    <div>
                      <p className="text-xs font-bold text-foreground">
                        {item.qty}x {item.name}
                      </p>
                      <p className="font-mono text-xs text-success">
                        {formatPrice(item.price * item.qty)}
                      </p>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => addToResources(item.name, item.price)}
                        className="text-muted-foreground transition-colors hover:text-primary"
                        aria-label="Move to resources"
                        title="Usar recurso proprio"
                      >
                        <Gem className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => removeFromCart(item.name)}
                        className="text-muted-foreground transition-colors hover:text-destructive"
                        aria-label={`Remove ${item.name}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Totals */}
          <div className="border-t border-border p-4">
            <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
              {"Valor Cobrado Ingame (\u20AC)"}
            </label>
            <input
              type="text"
              value={ingameValue}
              onChange={(e) => setIngameValue(e.target.value)}
              className="mt-1 w-full rounded border border-border bg-input px-3 py-2 font-mono text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            />

            <div className="mt-3 flex items-center justify-between rounded border border-border bg-secondary px-3 py-2">
              <span className="text-xs font-bold uppercase text-muted-foreground">
                Sistema
              </span>
              <span className="font-mono text-sm font-bold text-destructive">
                {formatPrice(systemTotal)}
              </span>
            </div>

            <div className="mt-1 flex items-center justify-between px-3 py-2">
              <span className="text-xs font-bold uppercase text-foreground">
                TOTAL
              </span>
              <span className="font-mono text-lg font-bold text-destructive">
                {formatPrice(grandTotal)}
              </span>
            </div>

            <button
              onClick={handleSubmit}
              disabled={cart.length === 0}
              className="mt-2 w-full rounded-lg bg-secondary py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground transition-colors disabled:opacity-50 hover:enabled:bg-primary hover:enabled:text-primary-foreground"
            >
              {cart.length === 0
                ? "Selecione uma Peca"
                : "Submeter Servico"}
            </button>
          </div>
        </div>
      </div>

      {/* Right: Resources */}
      <aside className="hidden w-64 flex-col gap-4 xl:flex">
        <div className="flex flex-1 flex-col rounded-lg border border-border bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <h3 className="flex items-center gap-2 font-mono text-sm font-bold text-primary">
              <Gem className="h-4 w-4" />
              RECURSOS
            </h3>
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-[10px] font-bold text-foreground">
              {resources.length}
            </span>
          </div>

          <div className="flex-1 overflow-auto p-4">
            {resources.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center gap-2 text-muted-foreground">
                <Gem className="h-8 w-8 opacity-50" />
                <p className="text-xs uppercase tracking-wider">
                  Aguardando Selecao
                </p>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                {resources.map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center justify-between rounded border border-border bg-secondary px-3 py-2"
                  >
                    <div>
                      <p className="text-xs font-bold text-foreground">
                        {item.qty}x {item.name}
                      </p>
                    </div>
                    <button
                      onClick={() => removeFromResources(item.name)}
                      className="text-muted-foreground transition-colors hover:text-destructive"
                      aria-label={`Remove resource ${item.name}`}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="border-t border-border px-5 py-3">
            <p className="text-center text-[10px] uppercase tracking-wider text-muted-foreground">
              Verifica sempre o stock antes de comecar
            </p>
          </div>
        </div>
      </aside>
    </div>
  )
}
