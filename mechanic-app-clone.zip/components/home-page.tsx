"use client"

import { useAuth } from "@/lib/auth-context"
import { RECENT_ACTIVITY, NOTICES } from "@/lib/store"
import { Wrench, Package } from "lucide-react"
import type { Page } from "./navbar"

interface HomePageProps {
  onNavigate: (page: Page) => void
}

function formatCurrency(value: number): string {
  return value.toLocaleString("pt-PT", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }) + " \u20AC"
}

export function HomePage({ onNavigate }: HomePageProps) {
  const { user } = useAuth()
  const displayName = user?.username.toUpperCase() ?? "USER"

  return (
    <div className="flex flex-1 gap-6 overflow-hidden p-6">
      {/* Main content */}
      <div className="flex flex-1 flex-col gap-6 overflow-auto">
        {/* Header with stats */}
        <div className="flex flex-wrap items-end justify-between gap-4">
          <h1 className="font-mono text-3xl font-bold italic text-foreground">
            {"PAINEL DE "}
            <span className="text-primary">{displayName}</span>
          </h1>

          <div className="flex rounded-lg border border-border bg-card">
            <div className="border-r border-border px-5 py-3">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {"Faturacao Pessoal"}
              </p>
              <p className="font-mono text-xl font-bold text-primary">{"0,00 \u20AC"}</p>
            </div>
            <div className="border-r border-border px-5 py-3">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {"Servicos"}
              </p>
              <p className="font-mono text-xl font-bold text-foreground">0</p>
            </div>
            <div className="px-5 py-3">
              <p className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                {"Pagamento (50%)"}
              </p>
              <p className="font-mono text-xl font-bold text-primary">{"0,00 \u20AC"}</p>
            </div>
          </div>
        </div>

        {/* Action cards */}
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => onNavigate("servico")}
            className="flex items-center justify-between rounded-lg border border-border bg-card p-6 text-left transition-colors hover:border-primary/50"
          >
            <div>
              <h2 className="font-mono text-lg font-bold text-foreground">INICIAR SERVICO</h2>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">
                {"Calculadora de Craft & Venda"}
              </p>
            </div>
            <Wrench className="h-8 w-8 text-muted-foreground" />
          </button>

          <button
            onClick={() => onNavigate("logistica")}
            className="flex items-center justify-between rounded-lg border border-border bg-card p-6 text-left transition-colors hover:border-primary/50"
          >
            <div>
              <h2 className="font-mono text-lg font-bold text-foreground">LOGISTICA</h2>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">
                {"Reposicao e Reembolsos"}
              </p>
            </div>
            <Package className="h-8 w-8 text-muted-foreground" />
          </button>
        </div>

        {/* Recent activity */}
        <div className="rounded-lg border border-border bg-card">
          <div className="flex items-center gap-2 border-b border-border px-5 py-3">
            <span className="h-2 w-2 rounded-full bg-primary" />
            <h3 className="font-mono text-sm font-bold uppercase text-foreground">
              Atividade Recente (Oficina)
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left">
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Mecanico
                  </th>
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Conteudo
                  </th>
                  <th className="px-5 py-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Data
                  </th>
                  <th className="px-5 py-3 text-right text-xs font-bold uppercase tracking-wider text-muted-foreground">
                    Faturado
                  </th>
                </tr>
              </thead>
              <tbody>
                {RECENT_ACTIVITY.map((entry, i) => (
                  <tr key={i} className="border-b border-border last:border-0">
                    <td className="whitespace-nowrap px-5 py-3 font-mono text-xs font-bold text-primary">
                      {entry.mechanic}
                    </td>
                    <td className="px-5 py-3 text-xs text-muted-foreground">
                      {entry.content}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3 text-xs text-muted-foreground">
                      {entry.date}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3 text-right font-mono text-sm font-bold text-success">
                      {formatCurrency(entry.billed)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Notices sidebar */}
      <aside className="hidden w-80 flex-shrink-0 flex-col gap-4 lg:flex">
        <div className="rounded-lg border border-primary/30 bg-card">
          <div className="flex items-center justify-between border-b border-border px-5 py-3">
            <h3 className="flex items-center gap-2 font-mono text-sm font-bold text-primary">
              <span>{"!!"}</span>
              AVISOS DA CHEFIA
            </h3>
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-secondary text-[10px] font-bold text-foreground">
              {NOTICES.length}
            </span>
          </div>

          <div className="flex flex-col gap-px">
            {NOTICES.map((notice, i) => (
              <div
                key={i}
                className="border-b border-border px-5 py-4 last:border-0"
              >
                <p className="text-sm leading-relaxed text-foreground">
                  {'"'}{notice.text}{'"'}
                </p>
                <p className="mt-2 text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                  {notice.author} {"- "}{notice.date}
                </p>
              </div>
            ))}
          </div>
        </div>
      </aside>
    </div>
  )
}
